package com.example.quizzapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.view.View.ROTATION
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class QuizQuestionsActivity : AppCompatActivity(), OnClickListener {

    private var mCurrentPosition : Int = 1
    private var mQuestionList : ArrayList<Question>? = null
    private var mSelectedOptionPosition : Int = 0
    private var mCorrectAnswers : Int = 0
    private var mUserName : String? = null



    lateinit var ivFlag : ImageView
    lateinit var progressBar: ProgressBar
    lateinit var tvCount : TextView
    lateinit var tvQuestion: TextView
    lateinit var tvVar1 : TextView
    lateinit var tvVar2  : TextView
    lateinit var tvVar3 : TextView
    lateinit var tvVar4 : TextView
    lateinit var btnSubmit : Button

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_questions)



        ivFlag = findViewById(R.id.ivFlag)
        progressBar = findViewById(R.id.progressBar)
        tvCount = findViewById(R.id.tvCount)
        tvQuestion = findViewById(R.id.tvQuestion)
        tvVar1 = findViewById(R.id.tvVar1)
        tvVar2 = findViewById(R.id.tvVar2)
        tvVar3 = findViewById(R.id.tvVar3)
        tvVar4 = findViewById(R.id.tvVar4)
        btnSubmit = findViewById(R.id.btnSubmit)

// preia numele introdus in prima pagina de catre user
        mUserName = intent.getStringExtra(Constants.User_Name)

        mQuestionList = Constants.getQuestions()
        setQuestion()



        tvVar1.setOnClickListener(this)
        tvVar2.setOnClickListener(this)
        tvVar3.setOnClickListener(this)
        tvVar4.setOnClickListener(this)
        btnSubmit.setOnClickListener(this)


    }

    private fun setQuestion () {

        val question = mQuestionList!!.get(mCurrentPosition-1)

        defaultOptionsView()

        if (mCurrentPosition == mQuestionList!!.size) {
            btnSubmit.text = "FINISH"
        } else {
            btnSubmit.text = " SUBMIT"
        }


        progressBar.progress = mCurrentPosition
        tvCount.text = "$mCurrentPosition" + "/" + progressBar.max

        tvQuestion.text = question.question
        ivFlag.setImageResource(question.image)
        tvVar1.text = question.optionOne
        tvVar2.text = question.optionTwo
        tvVar3.text = question.optionThree
        tvVar4.text = question.optionFour

    }

    private fun defaultOptionsView() {
        val options = ArrayList<TextView>()
        options.add(0, tvVar1)
        options.add(1, tvVar2)
        options.add(2, tvVar3)
        options.add(3, tvVar4)


        for (option in options ) {
            option.setTextColor(Color.parseColor("#7A8089"))
            option.typeface = Typeface.DEFAULT
            option.background = ContextCompat.getDrawable(
                this,
                R.drawable.default_option_border_bg
            )

        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tvVar1 -> {
                selectedOptionView(tvVar1, 1)
            }
            R.id.tvVar2 -> {
                selectedOptionView(tvVar2, 2)
            }
            R.id.tvVar3 -> {
                selectedOptionView(tvVar3, 3)
            }
            R.id.tvVar4 -> {
                selectedOptionView(tvVar4, 4)
            }

            /*
             btnStart.setOnClickListener {

            if (etName.text.toString().isEmpty()) {
                Toast.makeText(this, "You have to type your name before going further", Toast.LENGTH_SHORT).show()
            } else {
                // daca etName != isEmpty -> se trece la QuizQuestionsActivity
                val intent = Intent(this, QuizQuestionsActivity::class.java)
                intent.putExtra(Constants.User_Name, etName.text.toString())
                startActivity(intent)
                // inchide prima pagina la care ne vom intoarce la final
                finish()
            }

             */
            R.id.btnSubmit -> {
                if (mSelectedOptionPosition == 0) {
                    mCurrentPosition++

                    when {
                        mCurrentPosition <= mQuestionList!!.size -> {
                            setQuestion()
                        }
                        else -> {
                            val intent = Intent(this, ResultActivity::class.java)
                            intent.putExtra(Constants.User_Name, mUserName)
                            intent.putExtra(Constants.Correct_Answer, mCorrectAnswers)
                            intent.putExtra(Constants.Total_Questions, mQuestionList!!.size)
                            startActivity(intent)
                            finish()
                        }
                    }
                } else {
                    val question = mQuestionList?.get(mCurrentPosition - 1)

                    if (question!!.correctAnswer != mSelectedOptionPosition) {
                        answerView(mSelectedOptionPosition, R.drawable.wrong_option_border_bg)
                    } else {
                        mCorrectAnswers++

                    }
                    answerView(question.correctAnswer, R.drawable.correct_option_border_bg)

                    if (mCurrentPosition == mQuestionList!!.size) {
                        btnSubmit.text = "FINISH"
                    }
                    else {
                        btnSubmit.text = "Go to next question"
                    }

                    mSelectedOptionPosition = 0
                }
            }
        }
    }

    private fun answerView (answer : Int, drawableView : Int) {
        when (answer) {
            1-> {
                tvVar1.background = ContextCompat.getDrawable(
                    this, drawableView
                )
                }
            2-> {
                tvVar2.background = ContextCompat.getDrawable(
                    this, drawableView
                )
            }
            3-> {
                tvVar3.background = ContextCompat.getDrawable(
                    this, drawableView
                )
            }
            4-> {
                tvVar4.background = ContextCompat.getDrawable(
                    this, drawableView
                )
            }
        }
    }

    private fun selectedOptionView(tv: TextView, selectedOptionNum : Int) {

        defaultOptionsView()
        mSelectedOptionPosition = selectedOptionNum

        tv.setTextColor(Color.parseColor("#363A43"))
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.background = ContextCompat.getDrawable(
            this,
            R.drawable.selected_option_border_bg
        )

    }
}