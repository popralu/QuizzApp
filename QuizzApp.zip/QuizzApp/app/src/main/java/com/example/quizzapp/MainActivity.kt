
package com.example.quizzapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var etName : EditText
    lateinit var btnStart : Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etName = findViewById(R.id.etName)
        btnStart = findViewById(R.id.btnStart)

        btnStart.setOnClickListener {

            if (etName.text.toString().isEmpty()) {
                Toast.makeText(this, "You have to type your name before going further", Toast.LENGTH_SHORT).show()
            } else {
                // daca etName != isEmpty -> se trece la QuizQuestionsActivity
                val intent = Intent(this, QuizQuestionsActivity::class.java)
                intent.putExtra(Constants.User_Name, etName.text.toString())
                startActivity(intent)
                // inchide prima pagina la care ne vom intoarce la final
                finish()
            }

        }

    }
}